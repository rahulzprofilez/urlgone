## URL Uploader Bot
---

An Open Source ALL-In-One Telegram RoBot, that can do lot of things.

**My Features**:

👉 All Supported Video Formats of https://rg3.github.io/youtube-dl/supportedsites.html

👉 Upload as file from any HTTP link

### Installation

#### The Easy Way

#### You can also tap the Deploy To Heroku button below to deploy straight to Heroku!

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/TGExplore/TG-URL-Uploader/tree/master)

#### The Hard Way

```sh
virtualenv -p python3 VENV
. ./VENV/bin/activate
pip install -r requirements.txt
cp sample_config.py config.py
--- EDIT config.py values appropriately ---
python bot.py
```


#### LICENSE
- GPLv3
